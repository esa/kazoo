/* Functions to be filled by the user (never overwritten by buildsupport tool) */

#include "taste_probe.h"

#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include "Context-taste-probe.h"

/* List of active monitorings */
static asn1SccTASTE_Peek_list peeks;

void taste_probe_startup()
{
    printf ("[taste-probe] startup\n");

    /* Initialize the list of active monitorings to 0 */
    peeks.nCount = 0;
}

void taste_probe_PI_add_monitorings(const asn1SccTASTE_Peek_list *monitorings)
{
    int added_peeks = monitorings->nCount;
    int i	    = 0;
    
    /* Check that user does not try to exceed the maximum number 
     * of monitorings (configured in a context parameter) */
    if ((added_peeks + peeks.nCount) > taste_probe_ctxt.max_monitoring_number) {
	added_peeks = taste_probe_ctxt.max_monitoring_number - peeks.nCount;
	printf ("[taste-probe] Warning: exceeding the maxium number of monitorings (%lld)\n",
	    taste_probe_ctxt.max_monitoring_number);
    } 

    /* Add monitorings to the list (ignore if monitoring is already present) */
    for (i=0; i<added_peeks; i++) {
	int	j	= 0;
	bool	check	= true;
	int	id	= monitorings->arr[i].base_address +
			  monitorings->arr[i].offset;

	for (j=0; j<peeks.nCount; j++) {
	    if (id == (peeks.arr[j].base_address + peeks.arr[j].offset))
		check = false;
	}
	if (true == check) {
	    peeks.arr[peeks.nCount] = monitorings->arr[i];
	    peeks.nCount ++;
	    printf("[Peek-Poke] Added monitoring of address #%d\n", id);
	}
    }
}

void taste_probe_PI_patch_memory(const asn1SccTASTE_Poke_list *pokes)
{
    int i = 0;

    /* For each poke, patch memory with address referenced by id */
    for (i=0; i<pokes->nCount; i++) {
	switch (pokes->arr[i].values.arr[0].kind) {
	    case int_32_PRESENT:
		*(int *)pokes->arr[i].id = (int) pokes->arr[i].values.arr[0].u.int_32;				    
		break;    
	    case int_64_PRESENT:    
		*(long long *)pokes->arr[i].id = (long long) pokes->arr[i].values.arr[0].u.int_64;
		break;
	    case real_single_PRESENT:
		*(float *)pokes->arr[i].id = (float) pokes->arr[i].values.arr[0].u.real_single;
		break;
	    case real_double_PRESENT:
		*(double *)pokes->arr[i].id = (double) pokes->arr[i].values.arr[0].u.real_double;
		break;
	    case octet_string_PRESENT:
		memcpy ((unsigned int *)pokes->arr[i].id, 
			 pokes->arr[i].values.arr[0].u.octet_string.arr,
			 pokes->arr[i].values.arr[0].u.octet_string.nCount);
		break;
	    default: break;
	}
    }
}

void taste_probe_PI_remove_monitorings(const asn1SccTASTE_Peek_id_list *ids)
{
    int i = 0,
	j = 0,
	k = 0;

    for (i=0; i<ids->nCount; i++) {
	for (j=0; j<peeks.nCount; j++) {
	    if (ids->arr[i] == (peeks.arr[j].base_address+peeks.arr[j].offset)) {
		for (k=j; k<peeks.nCount-1; k++) {
		    peeks.arr[k]=peeks.arr[k+1];
		}
		peeks.nCount--;
		break;
	    }
	}
    }

}

void taste_probe_PI_periodic_monitoring()
{
    asn1SccTASTE_Monitoring_list out = empty_poke_list;
    static int cycle = 0;
    int i = 0, 
	j = 0;

    out.nCount = 0;

    cycle = (cycle + 1) % 10;

    for (i=0; i<peeks.nCount; i++) {
	if (0 == (cycle % peeks.arr[i].sample_time)) {
	    out.arr[i].id = peeks.arr[i].base_address + peeks.arr[i].offset;
	    for (j=0; j<peeks.arr[i].nb_of_elements; j++) {
		switch (peeks.arr[i].base_type) {
		    case asn1Sccint_32:
			out.arr[out.nCount].values.arr[j].u.int_32 = 
			    *(((int *)out.arr[out.nCount].id)+j);
			out.arr[out.nCount].values.arr[j].kind = int_32_PRESENT;
			break;
		    case asn1Sccint_64:
                        out.arr[i].values.arr[j].u.int_64 =
                            *(((long long *)out.arr[i].id)+j);
			out.arr[out.nCount].values.arr[j].kind = int_64_PRESENT;
			break;
		    case asn1Sccreal_single:
			out.arr[out.nCount].values.arr[j].u.real_single =
                            *(((float *)out.arr[out.nCount].id)+j);
			out.arr[out.nCount].values.arr[j].kind = real_single_PRESENT;
                        break;
		    case asn1Sccreal_double:
			out.arr[out.nCount].values.arr[j].u.real_double =
                            *(((double *)out.arr[out.nCount].id)+j);
			out.arr[out.nCount].values.arr[j].kind = real_double_PRESENT;
                        break;
		    case asn1Sccoctet_string: // nb_of_elements for octet string=size of the string
			if (j > 0) break;
			memcpy (out.arr[out.nCount].values.arr[j].u.octet_string.arr,
			    (((char *)out.arr[out.nCount].id)+j),peeks.arr[i].nb_of_elements);
			out.arr[out.nCount].values.arr[j].u.octet_string.nCount = peeks.arr[i].nb_of_elements;
			out.arr[out.nCount].values.arr[j].kind = octet_string_PRESENT;
                        break;
		    default: break;   
		}
		if (peeks.arr[i].base_type != asn1Sccoctet_string)
		    out.arr[out.nCount].values.nCount++;
		else
		    out.arr[out.nCount].values.nCount = 1;
	    }	    
	    out.nCount ++;
	}	
    }    
 if (out.nCount > 0) taste_probe_RI_update_monitorings(&out);
}

