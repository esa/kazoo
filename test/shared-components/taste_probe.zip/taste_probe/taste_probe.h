/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_taste_probe__
#define __USER_CODE_H_taste_probe__

#include "C_ASN1_Types.h"

void taste_probe_startup();

void taste_probe_PI_add_monitorings(const asn1SccTASTE_Peek_list *);

void taste_probe_PI_patch_memory(const asn1SccTASTE_Poke_list *);

void taste_probe_PI_remove_monitorings(const asn1SccTASTE_Peek_id_list *);

void taste_probe_PI_periodic_monitoring();

extern void taste_probe_RI_update_monitorings(const asn1SccTASTE_Monitoring_list *);


#endif
